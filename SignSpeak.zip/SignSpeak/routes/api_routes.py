from flask import Blueprint, jsonify, request
from services.gesture_service import GestureService
from services.speech_service import SpeechService
import logging

logger = logging.getLogger(__name__)

api_bp = Blueprint('api', __name__)
gesture_service = GestureService()
speech_service = SpeechService()

@api_bp.route('/translate', methods=['POST'])
def api_translate():
    """API endpoint for text translation"""
    try:
        data = request.get_json()
        if not data or 'text' not in data:
            return jsonify({'error': 'Text is required'}), 400
        
        input_text = data['text'].strip()
        translation_type = data.get('type', 'text')
        
        if not input_text:
            return jsonify({'error': 'Text cannot be empty'}), 400
        
        result = gesture_service.text_to_gestures(input_text, translation_type)
        return jsonify(result)
        
    except Exception as e:
        logger.error(f"API translation error: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/gestures', methods=['GET'])
def api_get_gestures():
    """API endpoint to get available gestures"""
    try:
        category = request.args.get('category')
        if category:
            gestures = gesture_service.get_gesture_by_category(category)
        else:
            from models import Gesture
            gestures = Gesture.query.limit(100).all()  # Limit to prevent large responses
        
        return jsonify([gesture.to_dict() for gesture in gestures])
        
    except Exception as e:
        logger.error(f"API get gestures error: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/gesture/<word>', methods=['GET'])
def api_get_gesture(word):
    """API endpoint to get a specific gesture"""
    try:
        gesture = gesture_service.find_gesture(word.lower())
        if gesture:
            return jsonify(gesture.to_dict())
        else:
            return jsonify({'error': 'Gesture not found'}), 404
            
    except Exception as e:
        logger.error(f"API get gesture error: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/stats', methods=['GET'])
def api_get_stats():
    """API endpoint for gesture database statistics"""
    try:
        stats = gesture_service.get_gesture_stats()
        return jsonify(stats)
        
    except Exception as e:
        logger.error(f"API stats error: {e}")
        return jsonify({'error': str(e)}), 500

@api_bp.route('/speech-recognize', methods=['POST'])
def api_speech_recognize():
    """API endpoint for speech recognition"""
    try:
        # This would typically handle audio file uploads
        # For now, we'll return a message about microphone access
        return jsonify({
            'error': 'Speech recognition via API requires audio file upload, which is not implemented in this version. Please use the web interface for microphone access.'
        }), 501
        
    except Exception as e:
        logger.error(f"API speech recognition error: {e}")
        return jsonify({'error': str(e)}), 500

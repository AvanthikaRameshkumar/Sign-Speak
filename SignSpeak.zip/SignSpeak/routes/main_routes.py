from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify
from services.gesture_service import GestureService
from services.speech_service import SpeechService
import logging

logger = logging.getLogger(__name__)

main_bp = Blueprint('main', __name__)
gesture_service = GestureService()
speech_service = SpeechService()

@main_bp.route('/')
def index():
    """Homepage with introduction and quick start"""
    stats = gesture_service.get_gesture_stats()
    return render_template('index.html', stats=stats)

@main_bp.route('/translator')
def translator():
    """Main translator interface"""
    available_words = gesture_service.get_available_words()
    return render_template('translator.html', available_words=available_words)

@main_bp.route('/translate', methods=['POST'])
def translate():
    """Handle translation requests"""
    try:
        input_text = request.form.get('text', '').strip()
        translation_type = request.form.get('type', 'text')
        
        if not input_text:
            flash('Please enter some text to translate.', 'warning')
            return redirect(url_for('main.translator'))
        
        # Translate text to gestures
        result = gesture_service.text_to_gestures(input_text, translation_type)
        
        if result['success']:
            flash(f'Successfully translated "{input_text}" into {len(result["gesture_sequence"])} gestures.', 'success')
            return render_template('translator.html', 
                                 translation_result=result,
                                 available_words=gesture_service.get_available_words())
        else:
            flash(f'Translation failed: {result.get("error", "Unknown error")}', 'danger')
            return redirect(url_for('main.translator'))
            
    except Exception as e:
        logger.error(f"Error in translation: {e}")
        flash('An unexpected error occurred during translation.', 'danger')
        return redirect(url_for('main.translator'))

@main_bp.route('/speech-to-text', methods=['POST'])
def speech_to_text():
    """Handle speech recognition and translation"""
    try:
        # Recognize speech from microphone
        result = speech_service.recognize_from_microphone(timeout=10, phrase_time_limit=15)
        
        if result['success']:
            # Translate the recognized text
            translation_result = gesture_service.text_to_gestures(result['text'], 'speech')
            
            if translation_result['success']:
                flash(f'Speech recognized: "{result["text"]}"', 'success')
                return render_template('translator.html',
                                     translation_result=translation_result,
                                     recognized_text=result['text'],
                                     available_words=gesture_service.get_available_words())
            else:
                flash(f'Speech recognized but translation failed: {translation_result.get("error", "Unknown error")}', 'warning')
        else:
            flash(f'Speech recognition failed: {result["error"]}', 'danger')
        
        return redirect(url_for('main.translator'))
        
    except Exception as e:
        logger.error(f"Error in speech recognition: {e}")
        flash('An unexpected error occurred during speech recognition.', 'danger')
        return redirect(url_for('main.translator'))

// Sign Language Translator App JavaScript

class SignLanguageTranslator {
    constructor() {
        this.isRecording = false;
        this.recognition = null;
        this.speechSynthesis = window.speechSynthesis;
        this.currentVoice = null;
        this.initializeSpeechRecognition();
        this.initializeVoiceSynthesis();
        this.initializeEventListeners();
    }

    initializeSpeechRecognition() {
        // Check if browser supports speech recognition
        if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
            const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
            this.recognition = new SpeechRecognition();
            
            // Enhanced configuration for better recognition
            this.recognition.continuous = true;
            this.recognition.interimResults = true;
            this.recognition.lang = 'en-US';
            this.recognition.maxAlternatives = 3;
            
            let finalTranscript = '';
            let interimTranscript = '';
            
            this.recognition.onstart = () => {
                this.isRecording = true;
                this.updateRecordingUI(true);
                this.showStatus('🎤 Listening... Speak clearly!', 'info');
                finalTranscript = '';
                interimTranscript = '';
            };
            
            this.recognition.onresult = (event) => {
                finalTranscript = '';
                interimTranscript = '';
                
                for (let i = event.resultIndex; i < event.results.length; i++) {
                    const transcript = event.results[i][0].transcript;
                    if (event.results[i].isFinal) {
                        finalTranscript += transcript;
                    } else {
                        interimTranscript += transcript;
                    }
                }
                
                // Update text input with current transcript
                const textInput = document.getElementById('textInput');
                textInput.value = finalTranscript + interimTranscript;
                
                // Show interim results
                if (interimTranscript) {
                    this.showStatus(`Hearing: "${interimTranscript}"`, 'secondary');
                }
                
                // Auto-translate when we have final results
                if (finalTranscript.trim()) {
                    this.showStatus(`✓ Recognized: "${finalTranscript}"`, 'success');
                    this.recognition.stop();
                    setTimeout(() => {
                        this.translateText(finalTranscript.trim(), 'speech');
                    }, 500);
                }
            };
            
            this.recognition.onerror = (event) => {
                let errorMessage = 'Speech recognition error';
                switch(event.error) {
                    case 'no-speech':
                        errorMessage = 'No speech detected. Please try speaking louder.';
                        break;
                    case 'audio-capture':
                        errorMessage = 'Microphone not accessible. Please check permissions.';
                        break;
                    case 'not-allowed':
                        errorMessage = 'Microphone permission denied. Please enable microphone access.';
                        break;
                    case 'network':
                        errorMessage = 'Network error. Please check your internet connection.';
                        break;
                    default:
                        errorMessage = `Speech recognition error: ${event.error}`;
                }
                this.showStatus(errorMessage, 'danger');
                this.updateRecordingUI(false);
            };
            
            this.recognition.onend = () => {
                this.isRecording = false;
                this.updateRecordingUI(false);
                
                // If we have text but no final translation, process it
                const textInput = document.getElementById('textInput');
                const currentText = textInput.value.trim();
                if (currentText && !finalTranscript) {
                    this.showStatus(`Processing: "${currentText}"`, 'info');
                    this.translateText(currentText, 'speech');
                }
            };
        } else {
            console.warn('Speech recognition not supported in this browser');
            this.disableSpeechFeatures();
        }
    }

    initializeVoiceSynthesis() {
        if ('speechSynthesis' in window) {
            // Wait for voices to load
            if (this.speechSynthesis.getVoices().length === 0) {
                this.speechSynthesis.onvoiceschanged = () => {
                    this.setupVoices();
                };
            } else {
                this.setupVoices();
            }
        } else {
            console.warn('Speech synthesis not supported in this browser');
        }
    }

    setupVoices() {
        const voices = this.speechSynthesis.getVoices();
        
        // Prefer female voices for a friendlier avatar experience
        this.currentVoice = voices.find(voice => 
            voice.lang.startsWith('en') && 
            (voice.name.toLowerCase().includes('female') || 
             voice.name.toLowerCase().includes('woman') ||
             voice.name.toLowerCase().includes('samantha') ||
             voice.name.toLowerCase().includes('karen') ||
             voice.name.toLowerCase().includes('zira'))
        ) || voices.find(voice => voice.lang.startsWith('en')) || voices[0];

        console.log('Selected voice:', this.currentVoice?.name);
    }

    initializeEventListeners() {
        // Text input translation
        const textForm = document.getElementById('textForm');
        if (textForm) {
            textForm.addEventListener('submit', (e) => {
                e.preventDefault();
                const text = document.getElementById('textInput').value.trim();
                if (text) {
                    this.translateText(text, 'text');
                } else {
                    this.showStatus('Please enter some text to translate.', 'warning');
                }
            });
        }

        // Speech recognition button
        const speechButton = document.getElementById('speechButton');
        if (speechButton) {
            speechButton.addEventListener('click', () => {
                this.toggleSpeechRecognition();
            });
        }

        // Clear button
        const clearButton = document.getElementById('clearButton');
        if (clearButton) {
            clearButton.addEventListener('click', () => {
                this.clearResults();
            });
        }

        // Sample text buttons
        document.querySelectorAll('.sample-text-btn').forEach(button => {
            button.addEventListener('click', (e) => {
                const sampleText = e.target.dataset.text;
                document.getElementById('textInput').value = sampleText;
                this.translateText(sampleText, 'text');
            });
        });
    }

    toggleSpeechRecognition() {
        if (!this.recognition) {
            this.showStatus('Speech recognition is not supported in your browser. Try Chrome, Safari, or Edge.', 'danger');
            return;
        }

        if (this.isRecording) {
            this.recognition.stop();
            this.showStatus('Stopping speech recognition...', 'info');
        } else {
            try {
                // Check for microphone permissions first
                if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
                    navigator.mediaDevices.getUserMedia({ audio: true })
                        .then(() => {
                            this.recognition.start();
                        })
                        .catch((error) => {
                            this.showStatus('Microphone access denied. Please enable microphone permissions and try again.', 'danger');
                        });
                } else {
                    this.recognition.start();
                }
            } catch (error) {
                console.error('Speech recognition error:', error);
                this.showStatus('Error starting speech recognition. Please ensure your microphone is working and try again.', 'danger');
            }
        }
    }

    async translateText(text, type = 'text') {
        this.showLoading(true);
        
        try {
            const response = await fetch('/api/translate', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    text: text,
                    type: type
                })
            });

            const data = await response.json();
            
            if (data.success) {
                this.displayTranslationResults(data);
                this.showStatus(`Successfully translated into ${data.gesture_sequence.length} gestures!`, 'success');
            } else {
                this.showStatus(`Translation failed: ${data.error}`, 'danger');
            }
        } catch (error) {
            console.error('Translation error:', error);
            this.showStatus('Translation request failed. Please try again.', 'danger');
        } finally {
            this.showLoading(false);
        }
    }

    displayTranslationResults(data) {
        const resultsContainer = document.getElementById('translationResults');
        if (!resultsContainer) return;

        resultsContainer.innerHTML = '';
        resultsContainer.style.display = 'block';

        // Create results header
        const header = document.createElement('div');
        header.className = 'mb-3';
        header.innerHTML = `
            <h5>Translation Results</h5>
            <p><strong>Original:</strong> "${data.original_text}"</p>
            <p><strong>Processed for ASL:</strong> "${data.processed_text}"</p>
            <p><strong>Processing time:</strong> ${(data.processing_time * 1000).toFixed(2)}ms</p>
        `;
        resultsContainer.appendChild(header);

        // Create gesture sequence display
        const gestureContainer = document.createElement('div');
        gestureContainer.className = 'gesture-sequence';
        
        data.gesture_sequence.forEach((gesture, index) => {
            const gestureCard = this.createGestureCard(gesture, index + 1);
            gestureContainer.appendChild(gestureCard);
        });

        resultsContainer.appendChild(gestureContainer);

        // Show unmapped words if any
        if (data.unmapped_words && data.unmapped_words.length > 0) {
            const unmappedInfo = document.createElement('div');
            unmappedInfo.className = 'alert alert-info mt-3';
            unmappedInfo.innerHTML = `
                <h6>Words requiring fingerspelling:</h6>
                <p>${data.unmapped_words.join(', ')}</p>
                <small>These words will be fingerspelled letter by letter.</small>
            `;
            resultsContainer.appendChild(unmappedInfo);
        }

        // Add avatar display
        this.displayAvatar(data.gesture_sequence);
    }

    createGestureCard(gesture, number) {
        const card = document.createElement('div');
        card.className = 'col-md-6 col-lg-4 mb-3';
        
        const difficultyBadge = this.getDifficultyBadge(gesture.difficulty);
        const categoryBadge = this.getCategoryBadge(gesture.category);
        
        card.innerHTML = `
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <span class="fw-bold">${number}. ${gesture.word.toUpperCase()}</span>
                    <div>
                        ${categoryBadge}
                        ${difficultyBadge}
                    </div>
                </div>
                <div class="card-body">
                    <p class="card-text">${gesture.description}</p>
                    <div class="gesture-details">
                        <small class="text-muted">
                            <strong>Hand Shape:</strong> ${gesture.hand_shape}<br>
                            <strong>Movement:</strong> ${gesture.movement}<br>
                            <strong>Location:</strong> ${gesture.location}<br>
                            <strong>Orientation:</strong> ${gesture.orientation}
                        </small>
                    </div>
                </div>
            </div>
        `;
        
        return card;
    }

    getDifficultyBadge(difficulty) {
        const colors = ['success', 'info', 'warning', 'danger', 'dark'];
        const color = colors[Math.min(difficulty - 1, 4)];
        return `<span class="badge bg-${color}">${difficulty}/5</span>`;
    }

    getCategoryBadge(category) {
        return `<span class="badge bg-secondary">${category}</span>`;
    }

    displayAvatar(gestureSequence) {
        const avatarContainer = document.getElementById('avatarContainer');
        if (!avatarContainer) return;

        this.currentGestureSequence = gestureSequence;
        this.currentGestureIndex = 0;
        this.isAnimating = false;

        avatarContainer.innerHTML = `
            <div class="avatar-display text-center p-4">
                <div class="avatar-character">
                    <div id="avatarSvg" class="avatar-svg-container">
                        <img src="/static/images/avatar.svg" alt="ASL Avatar" class="img-fluid mb-3" style="max-width: 200px;">
                    </div>
                    <div id="currentGesture" class="current-gesture-display">
                        <div class="gesture-bubble">
                            <span id="gestureText">Ready to sign!</span>
                        </div>
                    </div>
                </div>
                <div class="gesture-animation-controls">
                    <h6>🤟 Avatar Animation</h6>
                    <p>Gesture sequence: ${gestureSequence.length} signs</p>
                    <div class="progress mb-3">
                        <div id="animationProgress" class="progress-bar" role="progressbar" style="width: 0%"></div>
                    </div>
                    <div class="btn-group-vertical d-grid gap-2">
                        <button type="button" class="btn btn-primary" onclick="translator.playGestureSequence()">
                            <i class="fas fa-play"></i> Start Sign & Voice
                        </button>
                        <button type="button" class="btn btn-outline-success" onclick="translator.speakFullText(translator.getCurrentText())">
                            <i class="fas fa-volume-up"></i> Speak Full Text
                        </button>
                        <div class="btn-group" role="group">
                            <button type="button" class="btn btn-outline-secondary" onclick="translator.pauseAnimation()">
                                <i class="fas fa-pause"></i> Pause
                            </button>
                            <button type="button" class="btn btn-outline-info" onclick="translator.resetAnimation()">
                                <i class="fas fa-redo"></i> Reset
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        avatarContainer.style.display = 'block';
    }

    playGestureSequence() {
        if (!this.currentGestureSequence || this.currentGestureSequence.length === 0) {
            this.showStatus('No gesture sequence to play!', 'warning');
            return;
        }

        if (this.isAnimating) {
            this.showStatus('Animation is already playing!', 'info');
            return;
        }

        this.isAnimating = true;
        this.currentGestureIndex = 0;
        this.showStatus('🎬 Starting gesture animation...', 'info');
        this.animateNextGesture();
    }

    animateNextGesture() {
        if (!this.isAnimating || this.currentGestureIndex >= this.currentGestureSequence.length) {
            this.completeAnimation();
            return;
        }

        const gesture = this.currentGestureSequence[this.currentGestureIndex];
        const progress = ((this.currentGestureIndex + 1) / this.currentGestureSequence.length) * 100;
        
        // Update progress bar
        const progressBar = document.getElementById('animationProgress');
        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }

        // Update gesture display
        this.displayCurrentGesture(gesture, this.currentGestureIndex + 1);

        // Animate the avatar
        this.animateAvatarForGesture(gesture);

        // Move to next gesture after delay
        this.currentGestureIndex++;
        setTimeout(() => {
            this.animateNextGesture();
        }, 2500); // 2.5 seconds per gesture
    }

    displayCurrentGesture(gesture, index) {
        const gestureText = document.getElementById('gestureText');
        const avatarSvg = document.getElementById('avatarSvg');
        
        if (gestureText) {
            gestureText.innerHTML = `
                <strong>${index}. ${gesture.word.toUpperCase()}</strong><br>
                <small>${gesture.description}</small>
            `;
        }

        // Add animation class to avatar
        if (avatarSvg) {
            avatarSvg.className = 'avatar-svg-container animate-gesture';
            setTimeout(() => {
                avatarSvg.className = 'avatar-svg-container';
            }, 2000);
        }

        // Speak the word while signing
        this.speakWord(gesture.word);

        this.showStatus(`🤟 Signing & Speaking: "${gesture.word}" - ${gesture.description}`, 'primary');
    }

    animateAvatarForGesture(gesture) {
        const avatar = document.querySelector('#avatarSvg img');
        if (!avatar) return;

        // Add gesture-specific animation classes based on gesture properties
        avatar.classList.add('gesture-animation');
        
        // Different animations based on gesture location and movement
        if (gesture.location === 'face' || gesture.location === 'head') {
            avatar.classList.add('gesture-face');
        } else if (gesture.location === 'chest' || gesture.location === 'heart') {
            avatar.classList.add('gesture-chest');
        } else if (gesture.movement === 'wave' || gesture.movement === 'side_to_side') {
            avatar.classList.add('gesture-wave');
        } else if (gesture.movement === 'circular') {
            avatar.classList.add('gesture-circular');
        } else {
            avatar.classList.add('gesture-generic');
        }

        // Remove animation classes after animation completes
        setTimeout(() => {
            avatar.className = 'img-fluid mb-3';
        }, 2000);
    }

    pauseAnimation() {
        if (this.isAnimating) {
            this.isAnimating = false;
            this.showStatus('⏸️ Animation paused.', 'warning');
        } else {
            this.showStatus('No animation is currently playing.', 'info');
        }
    }

    getCurrentText() {
        if (this.currentGestureSequence && this.currentGestureSequence.length > 0) {
            return this.currentGestureSequence.map(gesture => gesture.word).join(' ');
        }
        return document.getElementById('textInput')?.value || '';
    }

    resetAnimation() {
        this.isAnimating = false;
        this.currentGestureIndex = 0;
        
        // Stop any ongoing speech
        if (this.speechSynthesis) {
            this.speechSynthesis.cancel();
        }
        
        const progressBar = document.getElementById('animationProgress');
        const gestureText = document.getElementById('gestureText');
        const avatarSvg = document.getElementById('avatarSvg');
        
        if (progressBar) progressBar.style.width = '0%';
        if (gestureText) gestureText.textContent = 'Ready to sign & speak!';
        if (avatarSvg) avatarSvg.classList.remove('speaking');
        
        this.showStatus('🔄 Animation and voice reset.', 'info');
    }

    speakWord(word) {
        if (!this.speechSynthesis || !this.currentVoice) {
            console.log('Speech synthesis not available');
            return;
        }

        // Cancel any ongoing speech
        this.speechSynthesis.cancel();

        const utterance = new SpeechSynthesisUtterance(word);
        utterance.voice = this.currentVoice;
        utterance.rate = 0.8; // Slightly slower for clarity
        utterance.pitch = 1.1; // Slightly higher pitch for friendliness
        utterance.volume = 0.8;

        // Add visual feedback when speaking
        utterance.onstart = () => {
            const avatarSvg = document.getElementById('avatarSvg');
            if (avatarSvg) {
                avatarSvg.classList.add('speaking');
            }
        };

        utterance.onend = () => {
            const avatarSvg = document.getElementById('avatarSvg');
            if (avatarSvg) {
                avatarSvg.classList.remove('speaking');
            }
        };

        this.speechSynthesis.speak(utterance);
    }

    speakFullText(text) {
        if (!this.speechSynthesis || !this.currentVoice) {
            this.showStatus('Voice synthesis not available in this browser.', 'warning');
            return;
        }

        const utterance = new SpeechSynthesisUtterance(text);
        utterance.voice = this.currentVoice;
        utterance.rate = 0.9;
        utterance.pitch = 1.0;
        utterance.volume = 0.8;

        utterance.onstart = () => {
            this.showStatus('🔊 Avatar is speaking...', 'info');
        };

        utterance.onend = () => {
            this.showStatus('Voice output complete.', 'success');
        };

        this.speechSynthesis.speak(utterance);
    }

    completeAnimation() {
        this.isAnimating = false;
        
        const progressBar = document.getElementById('animationProgress');
        const gestureText = document.getElementById('gestureText');
        
        if (progressBar) progressBar.style.width = '100%';
        if (gestureText) {
            gestureText.innerHTML = '<strong>🎉 Animation Complete!</strong><br><small>All gestures performed</small>';
        }
        
        this.showStatus('✨ Gesture sequence completed! The avatar has finished signing and speaking.', 'success');
        
        // Reset after a delay
        setTimeout(() => {
            this.resetAnimation();
        }, 3000);
    }

    updateRecordingUI(isRecording) {
        const speechButton = document.getElementById('speechButton');
        if (speechButton) {
            if (isRecording) {
                speechButton.innerHTML = '<i class="fas fa-stop"></i> Stop Recording';
                speechButton.className = 'btn btn-danger';
            } else {
                speechButton.innerHTML = '<i class="fas fa-microphone"></i> Start Speech Recognition';
                speechButton.className = 'btn btn-primary';
            }
        }
    }

    disableSpeechFeatures() {
        const speechButton = document.getElementById('speechButton');
        if (speechButton) {
            speechButton.disabled = true;
            speechButton.innerHTML = '<i class="fas fa-microphone-slash"></i> Speech Not Supported';
            speechButton.className = 'btn btn-secondary';
        }
    }

    showLoading(show) {
        const loadingSpinner = document.getElementById('loadingSpinner');
        if (loadingSpinner) {
            loadingSpinner.style.display = show ? 'block' : 'none';
        }
    }

    showStatus(message, type = 'info') {
        // Remove existing status messages
        document.querySelectorAll('.status-message').forEach(msg => msg.remove());
        
        const statusDiv = document.createElement('div');
        statusDiv.className = `alert alert-${type} alert-dismissible fade show status-message`;
        statusDiv.innerHTML = `
            ${message}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;
        
        const container = document.querySelector('.container-fluid') || document.body;
        container.insertBefore(statusDiv, container.firstChild);
        
        // Auto-dismiss after 5 seconds
        setTimeout(() => {
            if (statusDiv.parentNode) {
                statusDiv.remove();
            }
        }, 5000);
    }

    clearResults() {
        const resultsContainer = document.getElementById('translationResults');
        const avatarContainer = document.getElementById('avatarContainer');
        const textInput = document.getElementById('textInput');
        
        if (resultsContainer) resultsContainer.style.display = 'none';
        if (avatarContainer) avatarContainer.style.display = 'none';
        if (textInput) textInput.value = '';
        
        this.showStatus('Results cleared.', 'info');
    }
}

// Initialize the translator when the page loads
let translator;
document.addEventListener('DOMContentLoaded', () => {
    translator = new SignLanguageTranslator();
});

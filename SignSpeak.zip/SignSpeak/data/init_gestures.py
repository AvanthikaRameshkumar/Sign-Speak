"""
Initialize the gesture database with common ASL signs
"""
import logging
from app import db
from models import Gesture

logger = logging.getLogger(__name__)

# Essential ASL vocabulary with gesture descriptions
ESSENTIAL_GESTURES = [
    # Greetings and Basic Communication
    {"word": "hello", "description": "Wave hand with open palm", "hand_shape": "open_5", "movement": "wave", "location": "side", "orientation": "palm_out", "category": "greeting", "difficulty": 1},
    {"word": "hi", "description": "Small wave with open hand", "hand_shape": "open_5", "movement": "small_wave", "location": "side", "orientation": "palm_out", "category": "greeting", "difficulty": 1},
    {"word": "goodbye", "description": "Wave hand back and forth", "hand_shape": "open_5", "movement": "wave", "location": "side", "orientation": "palm_out", "category": "greeting", "difficulty": 1},
    {"word": "bye", "description": "Quick wave with open hand", "hand_shape": "open_5", "movement": "quick_wave", "location": "side", "orientation": "palm_out", "category": "greeting", "difficulty": 1},
    {"word": "please", "description": "Circular motion on chest with flat hand", "hand_shape": "flat_b", "movement": "circular", "location": "chest", "orientation": "palm_down", "category": "politeness", "difficulty": 2},
    {"word": "thank", "description": "Touch chin then move hand forward", "hand_shape": "flat_b", "movement": "touch_forward", "location": "chin", "orientation": "palm_up", "category": "politeness", "difficulty": 2},
    {"word": "you", "description": "Point index finger toward person", "hand_shape": "index", "movement": "point", "location": "forward", "orientation": "palm_down", "category": "pronoun", "difficulty": 1},
    {"word": "sorry", "description": "Make fist and rub on chest in circular motion", "hand_shape": "fist", "movement": "circular_rub", "location": "chest", "orientation": "knuckles_down", "category": "politeness", "difficulty": 2},

    # Family and People
    {"word": "mother", "description": "Touch thumb to chin with open hand", "hand_shape": "open_5", "movement": "touch", "location": "chin", "orientation": "palm_left", "category": "family", "difficulty": 2},
    {"word": "father", "description": "Touch thumb to forehead with open hand", "hand_shape": "open_5", "movement": "touch", "location": "forehead", "orientation": "palm_right", "category": "family", "difficulty": 2},
    {"word": "family", "description": "Link both F handshapes in a circle", "hand_shape": "f_shape", "movement": "circle", "location": "neutral", "orientation": "palms_facing", "category": "family", "difficulty": 3},
    {"word": "friend", "description": "Hook index fingers together twice", "hand_shape": "index", "movement": "hook_twice", "location": "neutral", "orientation": "palms_down", "category": "relationship", "difficulty": 3},
    {"word": "person", "description": "Move flat hands down the sides of body", "hand_shape": "flat_b", "movement": "down", "location": "sides", "orientation": "palms_in", "category": "people", "difficulty": 2},

    # Basic Verbs
    {"word": "go", "description": "Point index fingers and move forward", "hand_shape": "index", "movement": "forward", "location": "neutral", "orientation": "palms_down", "category": "verb", "difficulty": 2},
    {"word": "come", "description": "Beckon with index fingers toward body", "hand_shape": "index", "movement": "beckon", "location": "neutral", "orientation": "palms_up", "category": "verb", "difficulty": 2},
    {"word": "see", "description": "Point two fingers from eyes outward", "hand_shape": "v_shape", "movement": "point_out", "location": "eyes", "orientation": "palm_down", "category": "verb", "difficulty": 2},
    {"word": "hear", "description": "Point index finger to ear", "hand_shape": "index", "movement": "touch", "location": "ear", "orientation": "palm_down", "category": "verb", "difficulty": 2},
    {"word": "say", "description": "Circular motion near mouth with index finger", "hand_shape": "index", "movement": "circular", "location": "mouth", "orientation": "palm_left", "category": "verb", "difficulty": 2},
    {"word": "know", "description": "Tap temple with fingers", "hand_shape": "flat_b", "movement": "tap", "location": "temple", "orientation": "palm_down", "category": "verb", "difficulty": 2},
    {"word": "think", "description": "Touch index finger to temple", "hand_shape": "index", "movement": "touch", "location": "temple", "orientation": "palm_down", "category": "verb", "difficulty": 2},
    {"word": "want", "description": "Claw hands pull toward body", "hand_shape": "claw", "movement": "pull", "location": "neutral", "orientation": "palms_up", "category": "verb", "difficulty": 2},
    {"word": "need", "description": "Index finger moves down sharply", "hand_shape": "index", "movement": "down_sharp", "location": "neutral", "orientation": "palm_down", "category": "verb", "difficulty": 2},
    {"word": "help", "description": "Flat hand on top of fist, lift up", "hand_shape": "flat_on_fist", "movement": "lift_up", "location": "neutral", "orientation": "palms_up", "category": "verb", "difficulty": 3},

    # Question Words
    {"word": "what", "description": "Wiggle index finger side to side", "hand_shape": "index", "movement": "wiggle", "location": "neutral", "orientation": "palm_up", "category": "question", "difficulty": 2},
    {"word": "where", "description": "Wiggle index finger back and forth", "hand_shape": "index", "movement": "side_to_side", "location": "neutral", "orientation": "palm_up", "category": "question", "difficulty": 2},
    {"word": "when", "description": "Circle index finger around index finger", "hand_shape": "index", "movement": "circle_around", "location": "neutral", "orientation": "palm_down", "category": "question", "difficulty": 3},
    {"word": "who", "description": "Circle index finger around lips", "hand_shape": "index", "movement": "circle", "location": "lips", "orientation": "palm_left", "category": "question", "difficulty": 3},
    {"word": "why", "description": "Touch forehead then wiggle fingers", "hand_shape": "middle_finger", "movement": "touch_wiggle", "location": "forehead", "orientation": "palm_down", "category": "question", "difficulty": 3},
    {"word": "how", "description": "Knuckles together, roll hands", "hand_shape": "fist", "movement": "roll", "location": "neutral", "orientation": "knuckles_together", "category": "question", "difficulty": 3},

    # Numbers (1-10)
    {"word": "one", "description": "Hold up index finger", "hand_shape": "index", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 1},
    {"word": "two", "description": "Hold up index and middle finger", "hand_shape": "v_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 1},
    {"word": "three", "description": "Hold up thumb, index and middle finger", "hand_shape": "three_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 1},
    {"word": "four", "description": "Hold up four fingers", "hand_shape": "four_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 1},
    {"word": "five", "description": "Hold up all five fingers", "hand_shape": "open_5", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 1},
    {"word": "six", "description": "Touch thumb to pinky, other fingers up", "hand_shape": "six_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 2},
    {"word": "seven", "description": "Touch thumb to ring finger", "hand_shape": "seven_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 2},
    {"word": "eight", "description": "Touch thumb to middle finger", "hand_shape": "eight_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 2},
    {"word": "nine", "description": "Touch thumb to index finger", "hand_shape": "nine_shape", "movement": "static", "location": "neutral", "orientation": "palm_out", "category": "number", "difficulty": 2},
    {"word": "ten", "description": "Shake thumb up", "hand_shape": "thumb_up", "movement": "shake", "location": "neutral", "orientation": "thumb_up", "category": "number", "difficulty": 2},

    # Colors
    {"word": "red", "description": "Touch lips with index finger and pull down", "hand_shape": "index", "movement": "touch_down", "location": "lips", "orientation": "palm_left", "category": "color", "difficulty": 2},
    {"word": "blue", "description": "Shake B handshape", "hand_shape": "b_shape", "movement": "shake", "location": "side", "orientation": "palm_down", "category": "color", "difficulty": 2},
    {"word": "green", "description": "Shake G handshape", "hand_shape": "g_shape", "movement": "shake", "location": "side", "orientation": "palm_down", "category": "color", "difficulty": 2},
    {"word": "yellow", "description": "Shake Y handshape", "hand_shape": "y_shape", "movement": "shake", "location": "side", "orientation": "palm_down", "category": "color", "difficulty": 2},
    {"word": "black", "description": "Draw line across forehead with index finger", "hand_shape": "index", "movement": "across", "location": "forehead", "orientation": "palm_down", "category": "color", "difficulty": 2},
    {"word": "white", "description": "Touch chest and pull away while closing fingers", "hand_shape": "open_5", "movement": "pull_close", "location": "chest", "orientation": "palm_down", "category": "color", "difficulty": 3},

    # Common Objects
    {"word": "book", "description": "Open palms like opening a book", "hand_shape": "flat_b", "movement": "open", "location": "neutral", "orientation": "palms_up", "category": "object", "difficulty": 2},
    {"word": "car", "description": "Hands on steering wheel motion", "hand_shape": "s_shape", "movement": "steer", "location": "neutral", "orientation": "knuckles_out", "category": "transportation", "difficulty": 2},
    {"word": "house", "description": "Outline roof and walls with hands", "hand_shape": "flat_b", "movement": "outline", "location": "above", "orientation": "palms_down", "category": "object", "difficulty": 3},
    {"word": "water", "description": "Tap W handshape on chin", "hand_shape": "w_shape", "movement": "tap", "location": "chin", "orientation": "palm_left", "category": "drink", "difficulty": 2},
    {"word": "food", "description": "Touch fingers to mouth repeatedly", "hand_shape": "flat_o", "movement": "tap_mouth", "location": "mouth", "orientation": "palm_down", "category": "food", "difficulty": 2},

    # Emotions
    {"word": "happy", "description": "Brush chest upward with flat hand", "hand_shape": "flat_b", "movement": "brush_up", "location": "chest", "orientation": "palm_down", "category": "emotion", "difficulty": 2},
    {"word": "sad", "description": "Drag fingers down face", "hand_shape": "open_5", "movement": "down", "location": "face", "orientation": "palms_back", "category": "emotion", "difficulty": 2},
    {"word": "angry", "description": "Claw hand pulls up from face", "hand_shape": "claw", "movement": "pull_up", "location": "face", "orientation": "palm_back", "category": "emotion", "difficulty": 3},
    {"word": "love", "description": "Cross fists over heart", "hand_shape": "fist", "movement": "cross", "location": "heart", "orientation": "knuckles_out", "category": "emotion", "difficulty": 2},

    # Time
    {"word": "now", "description": "Drop both hands down sharply", "hand_shape": "y_shape", "movement": "drop", "location": "neutral", "orientation": "palms_up", "category": "time", "difficulty": 2},
    {"word": "today", "description": "Sign NOW then DAY", "hand_shape": "y_shape", "movement": "drop_then_arc", "location": "neutral", "orientation": "palms_up", "category": "time", "difficulty": 3},
    {"word": "tomorrow", "description": "Touch cheek with thumb and move forward", "hand_shape": "thumb_up", "movement": "forward", "location": "cheek", "orientation": "thumb_up", "category": "time", "difficulty": 3},
    {"word": "yesterday", "description": "Touch cheek with thumb and move back", "hand_shape": "thumb_up", "movement": "backward", "location": "cheek", "orientation": "thumb_up", "category": "time", "difficulty": 3},

    # Basic Adjectives
    {"word": "good", "description": "Touch chin then move hand forward and down", "hand_shape": "flat_b", "movement": "touch_forward", "location": "chin", "orientation": "palm_up", "category": "adjective", "difficulty": 2},
    {"word": "bad", "description": "Touch chin then flip hand down", "hand_shape": "flat_b", "movement": "touch_flip", "location": "chin", "orientation": "palm_down", "category": "adjective", "difficulty": 2},
    {"word": "big", "description": "Hands apart, index fingers and thumbs up", "hand_shape": "l_shape", "movement": "apart", "location": "neutral", "orientation": "palms_facing", "category": "adjective", "difficulty": 2},
    {"word": "small", "description": "Hands close together, palms facing", "hand_shape": "flat_b", "movement": "close", "location": "neutral", "orientation": "palms_facing", "category": "adjective", "difficulty": 2},
    {"word": "hot", "description": "Claw hand at mouth, twist and throw down", "hand_shape": "claw", "movement": "twist_throw", "location": "mouth", "orientation": "palm_down", "category": "adjective", "difficulty": 3},
    {"word": "cold", "description": "Shiver with fists near shoulders", "hand_shape": "fist", "movement": "shiver", "location": "shoulders", "orientation": "knuckles_up", "category": "adjective", "difficulty": 2},

    # Yes/No and Basic Responses
    {"word": "yes", "description": "Nod fist up and down", "hand_shape": "fist", "movement": "nod", "location": "neutral", "orientation": "knuckles_forward", "category": "response", "difficulty": 1},
    {"word": "no", "description": "Snap thumb, index and middle finger together", "hand_shape": "three_snap", "movement": "snap", "location": "neutral", "orientation": "palm_down", "category": "response", "difficulty": 2},
    {"word": "maybe", "description": "Flat hands alternately up and down", "hand_shape": "flat_b", "movement": "alternate", "location": "neutral", "orientation": "palms_down", "category": "response", "difficulty": 3},
    {"word": "ok", "description": "Fingerspell O-K", "hand_shape": "fingerspell", "movement": "sequential", "location": "neutral", "orientation": "palm_out", "category": "response", "difficulty": 2},

    # Learning and Education
    {"word": "learn", "description": "Pull information from hand to head", "hand_shape": "flat_o", "movement": "pull_to_head", "location": "hand_to_head", "orientation": "palm_down", "category": "education", "difficulty": 3},
    {"word": "teach", "description": "Pull information from head toward person", "hand_shape": "flat_o", "movement": "pull_forward", "location": "head", "orientation": "palm_down", "category": "education", "difficulty": 3},
    {"word": "school", "description": "Clap hands twice", "hand_shape": "flat_b", "movement": "clap_twice", "location": "neutral", "orientation": "palms_together", "category": "education", "difficulty": 2},
    {"word": "read", "description": "Two fingers move down palm like reading", "hand_shape": "v_shape", "movement": "down_palm", "location": "palm", "orientation": "fingers_down", "category": "education", "difficulty": 2},
    {"word": "write", "description": "Pinch fingers and write on palm", "hand_shape": "pinch", "movement": "write", "location": "palm", "orientation": "palm_up", "category": "education", "difficulty": 2},

    # Common Prepositions
    {"word": "in", "description": "Put fingers into other hand", "hand_shape": "flat_o", "movement": "into", "location": "other_hand", "orientation": "palm_up", "category": "preposition", "difficulty": 2},
    {"word": "on", "description": "Place flat hand on other flat hand", "hand_shape": "flat_b", "movement": "place", "location": "other_hand", "orientation": "palm_down", "category": "preposition", "difficulty": 2},
    {"word": "under", "description": "Move hand under other hand", "hand_shape": "flat_b", "movement": "under", "location": "other_hand", "orientation": "palm_up", "category": "preposition", "difficulty": 2},
    {"word": "with", "description": "Bring fists together", "hand_shape": "fist", "movement": "together", "location": "neutral", "orientation": "knuckles_up", "category": "preposition", "difficulty": 2},

    # More Essential Words
    {"word": "more", "description": "Tap fingertips together", "hand_shape": "flat_o", "movement": "tap", "location": "neutral", "orientation": "fingertips_together", "category": "quantity", "difficulty": 2},
    {"word": "all", "description": "Circle one hand around the other", "hand_shape": "flat_b", "movement": "circle_around", "location": "other_hand", "orientation": "palm_down", "category": "quantity", "difficulty": 3},
    {"word": "some", "description": "Pull fingers across palm", "hand_shape": "flat_b", "movement": "across_palm", "location": "palm", "orientation": "palm_up", "category": "quantity", "difficulty": 3},
    {"word": "many", "description": "Pop up fingers repeatedly", "hand_shape": "s_to_5", "movement": "pop_up", "location": "neutral", "orientation": "palms_up", "category": "quantity", "difficulty": 3},
]

def initialize_gestures():
    """Initialize the gesture database with essential ASL signs"""
    try:
        # Check if gestures already exist
        existing_count = Gesture.query.count()
        if existing_count > 0:
            logger.info(f"Gesture database already initialized with {existing_count} gestures")
            return

        logger.info("Initializing gesture database...")
        
        # Add all essential gestures
        for gesture_data in ESSENTIAL_GESTURES:
            gesture = Gesture(**gesture_data)
            db.session.add(gesture)
        
        db.session.commit()
        logger.info(f"Successfully initialized gesture database with {len(ESSENTIAL_GESTURES)} gestures")
        
        # Log statistics
        categories = {}
        for gesture in ESSENTIAL_GESTURES:
            category = gesture['category']
            categories[category] = categories.get(category, 0) + 1
        
        logger.info("Gesture categories:")
        for category, count in categories.items():
            logger.info(f"  {category}: {count} gestures")
            
    except Exception as e:
        logger.error(f"Error initializing gesture database: {e}")
        db.session.rollback()
        raise

if __name__ == "__main__":
    # Can be run standalone for testing
    from app import app
    with app.app_context():
        initialize_gestures()

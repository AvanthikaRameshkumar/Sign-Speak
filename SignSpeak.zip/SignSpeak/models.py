from app import db
from datetime import datetime

class Gesture(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    word = db.Column(db.String(100), nullable=False, unique=True, index=True)
    description = db.Column(db.Text, nullable=False)
    hand_shape = db.Column(db.String(50), nullable=False)
    movement = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(50), nullable=False)
    orientation = db.Column(db.String(50), nullable=False)
    category = db.Column(db.String(50), nullable=False, default='general')
    difficulty = db.Column(db.Integer, nullable=False, default=1)  # 1-5 scale
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'word': self.word,
            'description': self.description,
            'hand_shape': self.hand_shape,
            'movement': self.movement,
            'location': self.location,
            'orientation': self.orientation,
            'category': self.category,
            'difficulty': self.difficulty
        }

class Translation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    input_text = db.Column(db.Text, nullable=False)
    processed_text = db.Column(db.Text, nullable=False)
    gesture_sequence = db.Column(db.JSON, nullable=False)
    translation_type = db.Column(db.String(20), nullable=False)  # 'text' or 'speech'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    processing_time = db.Column(db.Float, nullable=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'input_text': self.input_text,
            'processed_text': self.processed_text,
            'gesture_sequence': self.gesture_sequence,
            'translation_type': self.translation_type,
            'created_at': self.created_at.isoformat(),
            'processing_time': self.processing_time
        }

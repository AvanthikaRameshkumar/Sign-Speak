# Overview

This is an AI-powered Sign Language Translator that converts speech and text into American Sign Language (ASL) gestures. The application uses OpenAI's GPT models to process and simplify English text according to ASL grammar rules, then maps the processed text to a database of gesture descriptions. The system features a web interface with both text input and speech recognition capabilities, designed to bridge communication barriers for the deaf and hard-of-hearing community.

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Backend Framework
- **Flask**: Python web framework chosen for its simplicity and rapid development capabilities
- **SQLAlchemy**: ORM for database operations with declarative base model structure
- **Blueprint Architecture**: Routes organized into separate blueprints (main_routes, api_routes) for modular code organization

## Database Design
- **SQLite**: Default database for development with configurable PostgreSQL support via DATABASE_URL
- **Models**: Two primary entities - Gesture (stores ASL sign descriptions) and Translation (tracks translation history)
- **Gesture Schema**: Comprehensive gesture data including hand_shape, movement, location, orientation, category, and difficulty level

## AI Integration
- **OpenAI GPT-4o**: Core AI service for converting English text to ASL-friendly grammar structure
- **Speech Recognition**: Browser-based speech-to-text using Web Speech API
- **Text Processing Pipeline**: Input → OpenAI processing → gesture mapping → response generation

## Frontend Architecture
- **Jinja2 Templates**: Server-side rendering with Bootstrap for responsive UI
- **Progressive Enhancement**: Basic functionality works without JavaScript, enhanced with client-side features
- **Real-time Speech Recognition**: JavaScript-based audio capture and processing

## Service Layer
- **GestureService**: Handles text-to-gesture translation and database operations
- **OpenAIService**: Manages AI model interactions and text processing
- **SpeechService**: Handles audio input processing (server-side backup)

## Translation Pipeline
1. Input captured (text or speech)
2. OpenAI processes text for ASL grammar compatibility
3. Processed text mapped to gesture database
4. Unmapped words handled via fingerspelling fallback
5. Complete gesture sequence returned with animation instructions

# External Dependencies

## AI Services
- **OpenAI API**: GPT-4o model for natural language processing and ASL grammar conversion
- **Web Speech API**: Browser-native speech recognition (primary method)
- **SpeechRecognition library**: Python fallback for server-side audio processing

## Frontend Libraries
- **Bootstrap 5**: UI framework with dark theme support
- **Font Awesome**: Icon library for visual elements
- **jQuery**: JavaScript utilities and DOM manipulation

## Infrastructure
- **Flask ecosystem**: SQLAlchemy, Werkzeug middleware for proxy handling
- **Environment configuration**: Supports development (SQLite) and production (PostgreSQL) database configurations
- **Session management**: Secure session handling with configurable secret keys
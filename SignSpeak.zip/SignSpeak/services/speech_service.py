import speech_recognition as sr
import logging
import tempfile
import os

logger = logging.getLogger(__name__)

class SpeechService:
    def __init__(self):
        self.recognizer = sr.Recognizer()
        self.recognizer.energy_threshold = 300
        self.recognizer.dynamic_energy_threshold = True
        self.recognizer.dynamic_energy_adjustment_damping = 0.15
        self.recognizer.dynamic_energy_ratio = 1.5
        self.recognizer.pause_threshold = 0.8
        self.recognizer.operation_timeout = None
        self.recognizer.phrase_threshold = 0.3
        self.recognizer.non_speaking_duration = 0.5
        
    def recognize_from_microphone(self, timeout=5, phrase_time_limit=10):
        """
        Recognize speech from microphone input
        """
        try:
            with sr.Microphone() as source:
                logger.info("Adjusting for ambient noise...")
                self.recognizer.adjust_for_ambient_noise(source, duration=1)
                logger.info("Listening for speech...")
                
                audio = self.recognizer.listen(
                    source, 
                    timeout=timeout, 
                    phrase_time_limit=phrase_time_limit
                )
                
                logger.info("Processing speech...")
                text = self.recognizer.recognize_google(audio)
                logger.info(f"Speech recognized: {text}")
                return {
                    "success": True,
                    "text": text,
                    "error": None
                }
                
        except sr.UnknownValueError:
            logger.warning("Speech recognition could not understand audio")
            return {
                "success": False,
                "text": "",
                "error": "Could not understand the audio. Please speak clearly and try again."
            }
        except sr.RequestError as e:
            logger.error(f"Could not request results from speech recognition service: {e}")
            return {
                "success": False,
                "text": "",
                "error": "Speech recognition service is unavailable. Please try again later."
            }
        except sr.WaitTimeoutError:
            logger.warning("Listening timeout")
            return {
                "success": False,
                "text": "",
                "error": "Listening timeout. Please try speaking again."
            }
        except Exception as e:
            logger.error(f"Unexpected error in speech recognition: {e}")
            return {
                "success": False,
                "text": "",
                "error": "An unexpected error occurred. Please try again."
            }
    
    def recognize_from_audio_data(self, audio_data):
        """
        Recognize speech from audio data (for file uploads)
        """
        try:
            # Create temporary file
            with tempfile.NamedTemporaryFile(delete=False, suffix='.wav') as temp_audio:
                temp_audio.write(audio_data)
                temp_path = temp_audio.name
            
            # Load and process audio file
            with sr.AudioFile(temp_path) as source:
                audio = self.recognizer.record(source)
                text = self.recognizer.recognize_google(audio)
                
                # Clean up temporary file
                os.unlink(temp_path)
                
                logger.info(f"Speech recognized from file: {text}")
                return {
                    "success": True,
                    "text": text,
                    "error": None
                }
                
        except Exception as e:
            logger.error(f"Error processing audio file: {e}")
            return {
                "success": False,
                "text": "",
                "error": "Could not process audio file. Please ensure it's a valid audio format."
            }

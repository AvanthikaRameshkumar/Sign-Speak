import logging
from models import Gesture, Translation
from app import db
from services.openai_service import OpenAIService
import time

logger = logging.getLogger(__name__)

class GestureService:
    def __init__(self):
        self.openai_service = OpenAIService()
    
    def text_to_gestures(self, input_text, translation_type='text'):
        """
        Convert text to gesture sequence
        """
        start_time = time.time()
        
        try:
            # Process text with OpenAI for ASL structure
            processed_data = self.openai_service.process_for_sign_language(input_text)
            processed_text = processed_data.get('simplified', input_text)
            key_words = processed_data.get('key_words', input_text.split())
            
            # Map words to gestures
            gesture_sequence = []
            unmapped_words = []
            
            for word in key_words:
                gesture = self.find_gesture(word.lower().strip())
                if gesture:
                    gesture_sequence.append(gesture.to_dict())
                else:
                    unmapped_words.append(word)
                    # Add a placeholder for unmapped words
                    gesture_sequence.append({
                        'word': word,
                        'description': f'Fingerspell "{word.upper()}"',
                        'hand_shape': 'fingerspelling',
                        'movement': 'sequential',
                        'location': 'neutral',
                        'orientation': 'palm_out',
                        'category': 'fingerspelling',
                        'difficulty': 2
                    })
            
            processing_time = time.time() - start_time
            
            # Save translation record
            translation = Translation(
                input_text=input_text,
                processed_text=processed_text,
                gesture_sequence=gesture_sequence,
                translation_type=translation_type,
                processing_time=processing_time
            )
            db.session.add(translation)
            db.session.commit()
            
            logger.info(f"Successfully converted text to gestures: {len(gesture_sequence)} gestures")
            
            return {
                'success': True,
                'original_text': input_text,
                'processed_text': processed_text,
                'gesture_sequence': gesture_sequence,
                'unmapped_words': unmapped_words,
                'processing_time': processing_time,
                'translation_id': translation.id
            }
            
        except Exception as e:
            logger.error(f"Error converting text to gestures: {e}")
            return {
                'success': False,
                'error': str(e),
                'original_text': input_text,
                'gesture_sequence': [],
                'unmapped_words': [],
                'processing_time': time.time() - start_time
            }
    
    def find_gesture(self, word):
        """
        Find gesture for a specific word
        """
        # Try exact match first
        gesture = Gesture.query.filter_by(word=word.lower()).first()
        if gesture:
            return gesture
        
        # Try partial matches for variations
        gesture = Gesture.query.filter(Gesture.word.like(f'%{word}%')).first()
        if gesture:
            return gesture
            
        return None
    
    def get_gesture_by_category(self, category):
        """
        Get all gestures in a specific category
        """
        return Gesture.query.filter_by(category=category).all()
    
    def get_available_words(self):
        """
        Get all available words in the gesture database
        """
        gestures = Gesture.query.all()
        return [gesture.word for gesture in gestures]
    
    def get_gesture_stats(self):
        """
        Get statistics about the gesture database
        """
        total_gestures = Gesture.query.count()
        categories = db.session.query(Gesture.category, db.func.count(Gesture.id)).group_by(Gesture.category).all()
        recent_translations = Translation.query.order_by(Translation.created_at.desc()).limit(10).all()
        
        return {
            'total_gestures': total_gestures,
            'categories': dict(categories),
            'recent_translations': [t.to_dict() for t in recent_translations]
        }

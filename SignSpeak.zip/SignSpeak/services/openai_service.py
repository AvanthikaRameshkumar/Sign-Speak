import json
import os
import logging
from openai import OpenAI

logger = logging.getLogger(__name__)

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
openai = None

if OPENAI_API_KEY:
    openai = OpenAI(api_key=OPENAI_API_KEY)

class OpenAIService:
    def __init__(self):
        self.enabled = bool(OPENAI_API_KEY)
        if not self.enabled:
            logger.warning("OPENAI_API_KEY not set - OpenAI features will be disabled")
    
    def process_for_sign_language(self, text):
        """
        Process text for sign language translation by simplifying grammar
        and breaking down complex sentences.
        """
        if not self.enabled:
            # Fallback when OpenAI is not available
            words = text.lower().replace(',', '').replace('.', '').split()
            return {
                "original": text,
                "simplified": text,
                "key_words": words,
                "sentence_structure": "simple"
            }
        
        try:
            # the newest OpenAI model is "gpt-4o" which was released May 13, 2024.
            # do not change this unless explicitly requested by the user
            response = openai.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": """You are an expert in American Sign Language (ASL) grammar and structure. 
                        Your task is to convert English text into a format suitable for ASL translation.
                        
                        ASL Grammar Rules:
                        - Use simple, direct word order
                        - Remove articles (a, an, the) when possible
                        - Use present tense when possible
                        - Break complex sentences into simple ones
                        - Focus on key content words (nouns, verbs, adjectives)
                        - Remove unnecessary prepositions and conjunctions
                        
                        Respond with JSON in this format:
                        {
                            "original": "original text",
                            "simplified": "ASL-friendly text",
                            "key_words": ["word1", "word2", "word3"],
                            "sentence_structure": "subject-verb-object or other ASL pattern"
                        }"""
                    },
                    {"role": "user", "content": f"Convert this text for ASL: {text}"}
                ],
                response_format={"type": "json_object"},
                max_tokens=500
            )
            
            content = response.choices[0].message.content
            if content:
                result = json.loads(content)
            else:
                raise ValueError("Empty response from OpenAI")
            logger.info(f"Successfully processed text for ASL: {text}")
            return result
            
        except Exception as e:
            logger.error(f"Failed to process text with OpenAI: {e}")
            # Fallback to simple word extraction
            words = text.lower().replace(',', '').replace('.', '').split()
            return {
                "original": text,
                "simplified": text,
                "key_words": words,
                "sentence_structure": "simple"
            }
    
    def get_context_analysis(self, text):
        """
        Analyze text context to improve gesture selection
        """
        if not self.enabled:
            return {
                "emotion": "neutral",
                "formality": "informal", 
                "topic": "general",
                "urgency": "low"
            }
        
        try:
            response = openai.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {
                        "role": "system",
                        "content": """Analyze the context and emotion of the given text.
                        Respond with JSON in this format:
                        {
                            "emotion": "neutral|happy|sad|angry|excited|confused",
                            "formality": "formal|informal|casual",
                            "topic": "general category of the content",
                            "urgency": "low|medium|high"
                        }"""
                    },
                    {"role": "user", "content": text}
                ],
                response_format={"type": "json_object"},
                max_tokens=200
            )
            
            content = response.choices[0].message.content
            if content:
                return json.loads(content)
            else:
                raise ValueError("Empty response from OpenAI")
            
        except Exception as e:
            logger.error(f"Failed to analyze context: {e}")
            return {
                "emotion": "neutral",
                "formality": "informal",
                "topic": "general",
                "urgency": "low"
            }
